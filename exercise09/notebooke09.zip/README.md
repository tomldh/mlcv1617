This exercise description contains some automated checks and is thus provided as ipython notebook.
Please use the console to navigate to the location where you stored `Exercise 09.ipynb` and run "jupyter notebook".
This will open a browser window where you can choose this exercise.
